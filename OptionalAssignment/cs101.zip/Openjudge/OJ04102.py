""""""
n, m, k = map(int, input().split())
ns, ms = [], []
for _ in range(k):
    ni, mi = map(int, input().split())
    ns.append(ni)
    ms.append(mi)
