import time

start_time = time.time()

k = 0
for i in range(1000000000):
    k = i

end_time = time.time()
print(end_time - start_time)