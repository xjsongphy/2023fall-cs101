"""于2023-8-31测试通过"""
str_input = input()
if '1111111' in str_input or '0000000' in str_input:
    print('YES')
else:
    print('NO')