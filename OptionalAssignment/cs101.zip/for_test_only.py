# practices = set({})
# while True:
#     inputs = input()
#     if inputs == 'exit':
#         break
#     for i in inputs.split():
#         practices.add(int(i))
#
# print(len(practices))

from functools import cmp_to_key
m, n = int(input()), int(input())
ls = input().split()
dp = [0] + [-1]*(m + 1)


def k(i, j):
    return int(i + j) - int(j + i)


ls.sort(key=cmp_to_key(k), reverse=True)
for i in range(m, -1, -1):
    if len(ls[0]) == i:
        dp[i] = int(ls[0])
for i in range(1, n):
    l = len(ls[i])
    for j in range(m, 0, -1):
        if j - l < 0:
            break
        t = dp[j - l]
        if t == -1:
            continue
        else:
            t = ['', str(t)][t != 0]
            dp[j] = max(dp[j], int(t + ls[i]), int(ls[i] + t))
print(max(dp[1:]))
